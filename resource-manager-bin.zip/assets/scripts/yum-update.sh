#!/bin/bash
yum install python36-oci-cli -y